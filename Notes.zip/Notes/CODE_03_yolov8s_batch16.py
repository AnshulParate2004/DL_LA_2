"""
CODE FILE 3 — Config C: YOLOv8s, batch=16, imgsz=640
======================================================
VRAM: ~7 GB ✅ Comfortable on T4

This is the BASELINE model. Train this first to get a reference
mAP ceiling before comparing against your custom model.

Uses Ultralytics YOLOv8s — fine-tuned from pretrained COCO weights,
then evaluated on DocLayNet 7-class subset.

Key differences from CODE_02:
  - Uses Ultralytics API (not raw PyTorch)
  - Pretrained COCO backbone → faster convergence (~60-70 epochs vs 100)
  - Slightly higher mAP baseline expected (~72-75 mAP@50)
  - Your custom model from CODE_02 should chase this number
"""

import os, shutil
from pathlib import Path

# ─────────────────────────────────────────────
# STEP 0 — Install + GPU check
# ─────────────────────────────────────────────
!pip install ultralytics -q

import torch
from ultralytics import YOLO

print(f"PyTorch : {torch.__version__}")
print(f"GPU     : {torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU'}")
vram = torch.cuda.get_device_properties(0).total_memory / 1e9
print(f"VRAM    : {vram:.1f} GB")

# ─────────────────────────────────────────────
# STEP 1 — Paths (must match CODE_01 output)
# ─────────────────────────────────────────────
from google.colab import drive
drive.mount('/content/drive')

BASE_DIR     = '/content/drive/MyDrive/MVL_DL'
DATASET_YAML = os.path.join(BASE_DIR, 'doclaynet_10k', 'dataset.yaml')  # subset first
CHECKPT_DIR  = os.path.join(BASE_DIR, 'checkpoints', 'yolov8s_b16')
LOG_DIR      = os.path.join(BASE_DIR, 'logs')
os.makedirs(CHECKPT_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

print(f"Dataset : {DATASET_YAML}")
print(f"Exists  : {os.path.exists(DATASET_YAML)}")

# ─────────────────────────────────────────────
# STEP 2 — Load YOLOv8s (pretrained on COCO)
# ─────────────────────────────────────────────
model = YOLO('yolov8s.pt')  # downloads ~22MB automatically
print(model.info())

# ─────────────────────────────────────────────
# STEP 3 — Training
# Config C: batch=16, imgsz=640 → ~7 GB VRAM
# ─────────────────────────────────────────────
results = model.train(
    data        = DATASET_YAML,
    epochs      = 100,
    imgsz       = 640,
    batch       = 16,            # Config C
    device      = 0,             # GPU 0
    workers     = 2,
    lr0         = 1e-3,
    lrf         = 0.01,          # final LR = lr0 * lrf (cosine)
    warmup_epochs = 5,
    cos_lr      = True,
    amp         = True,          # fp16 auto mixed precision
    # ── Augmentation (document-safe) ──
    degrees     = 5.0,           # small rotation ±5°
    fliplr      = 0.0,           # NO horizontal flip — text direction!
    flipud      = 0.0,           # NO vertical flip
    hsv_h       = 0.0,
    hsv_s       = 0.2,
    hsv_v       = 0.3,
    mosaic      = 1.0,           # mosaic augmentation — great for DLA
    scale       = 0.3,
    translate   = 0.1,
    # ── Output ──
    project     = CHECKPT_DIR,
    name        = 'yolov8s_b16',
    save        = True,
    save_period = 10,            # save checkpoint every 10 epochs
    exist_ok    = True,
    patience    = 30,            # early stop if no improvement
    plots       = True,
    verbose     = True,
)

print("\n✅ Training complete")
print(f"Best weights → {CHECKPT_DIR}/yolov8s_b16/weights/best.pt")

# ─────────────────────────────────────────────
# STEP 4 — Evaluate on validation set
# ─────────────────────────────────────────────
best_model = YOLO(f'{CHECKPT_DIR}/yolov8s_b16/weights/best.pt')
metrics    = best_model.val(
    data    = DATASET_YAML,
    imgsz   = 640,
    batch   = 16,
    device  = 0,
    conf    = 0.25,
    iou     = 0.45,
    plots   = True,
    save_json = True,
)

CLS_NAMES = ['Caption','List-item','Picture','Section-header','Table','Text','Title']
print("\n" + "═"*55)
print("YOLOv8s CONFIG C — Validation Results")
print("═"*55)
print(f"mAP@50     : {metrics.box.map50:.4f}")
print(f"mAP@50-95  : {metrics.box.map:.4f}")
print("\nPer-class AP@50:")
for i, (name, ap) in enumerate(zip(CLS_NAMES, metrics.box.ap50)):
    star = " ← KEY" if name in ('Title','Section-header') else ""
    print(f"  {name:18s}: {ap:.4f}{star}")

# ─────────────────────────────────────────────
# STEP 5 — Quick inference test on a sample page
# ─────────────────────────────────────────────
from pathlib import Path
import random
from PIL import Image
import matplotlib.pyplot as plt
import matplotlib.patches as patches

CLS_COLORS = ['#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFEAA7','#DDA0DD','#FF8C00']

def run_inference_sample(model, dataset_yaml, n=2):
    data_root = str(Path(dataset_yaml).parent)
    val_imgs  = list((Path(data_root) / 'val' / 'images').glob('*.jpg'))
    if not val_imgs:
        val_imgs = list((Path(data_root) / 'val' / 'images').glob('*.png'))
    samples   = random.sample(val_imgs, min(n, len(val_imgs)))

    fig, axes = plt.subplots(1, n, figsize=(8*n, 10))
    if n == 1: axes = [axes]

    for ax, img_path in zip(axes, samples):
        result = model.predict(str(img_path), conf=0.25, iou=0.45, verbose=False)[0]
        img    = Image.open(img_path)
        ax.imshow(img)
        for box in result.boxes:
            x1,y1,x2,y2 = box.xyxy[0].tolist()
            cls  = int(box.cls[0])
            conf = float(box.conf[0])
            rect = patches.Rectangle((x1,y1), x2-x1, y2-y1,
                                      linewidth=2, edgecolor=CLS_COLORS[cls],
                                      facecolor='none')
            ax.add_patch(rect)
            ax.text(x1, y1-3, f"{CLS_NAMES[cls]} {conf:.2f}",
                    color=CLS_COLORS[cls], fontsize=7, weight='bold')
        ax.set_title(img_path.name[:40], fontsize=8)
        ax.axis('off')

    plt.tight_layout()
    out = os.path.join(LOG_DIR, 'yolov8s_inference_sample.png')
    plt.savefig(out, dpi=120)
    plt.show()
    print(f"Inference sample saved → {out}")

run_inference_sample(best_model, DATASET_YAML, n=2)

# ─────────────────────────────────────────────
# STEP 6 — Export for production
# ─────────────────────────────────────────────
# Export to TorchScript for use in MVL-AgneticAI
best_model.export(format='torchscript', imgsz=640)
best_model.export(format='onnx', imgsz=640, simplify=True)
print(f"Exports saved in {CHECKPT_DIR}/yolov8s_b16/weights/")

print("\n" + "="*60)
print("NEXT STEP: Run CODE_04_yolov8m_batch8.py for Config D")
print("Compare mAP between:")
print("  CODE_02 custom 10M  (Config A batch=16 / Config B batch=32)")
print("  CODE_03 YOLOv8s b16 (this file — baseline)")
print("  CODE_04 YOLOv8m b8  (next file — upper bound)")
