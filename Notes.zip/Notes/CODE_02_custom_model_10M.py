"""
CODE FILE 2 — Config A & B: Custom Model ~10M params
=====================================================
Config A: batch=16, imgsz=640 → ~6-8 GB VRAM  ✅ Comfortable
Config B: batch=32, imgsz=640 → ~10-12 GB VRAM ✅ Possible

Builds the full custom architecture from scratch in raw PyTorch:
  Backbone: ResNet-style 5-stage CNN
  Neck:     Feature Pyramid Network (FPN, 3 scales)
  Head:     YOLO-style detection head per scale
  Loss:     CIoU + BCE objectness + CrossEntropy class

No Ultralytics. No pretrained weights. Pure PyTorch.
"""

import os, math, time, random, shutil
from pathlib import Path
from collections import defaultdict

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.cuda.amp import GradScaler, autocast
from torch.utils.data import Dataset, DataLoader
import torchvision.ops as ops
from PIL import Image
import numpy as np
import albumentations as A
from albumentations.pytorch import ToTensorV2
import matplotlib.pyplot as plt

# ─────────────────────────────────────────────
# CONFIG — change BATCH_SIZE to switch A ↔ B
# ─────────────────────────────────────────────
BASE_DIR      = '/content/drive/MyDrive/MVL_DL'
DATA_YAML     = os.path.join(BASE_DIR, 'doclaynet_10k', 'dataset.yaml')  # start with subset
CHECKPT_DIR  = os.path.join(BASE_DIR, 'checkpoints', 'custom_10M')
LOG_DIR       = os.path.join(BASE_DIR, 'logs')

CFG = {
    # ── Toggle A vs B here ──
    'batch_size'      : 16,    # Config A=16 (~6-8GB) | Config B=32 (~10-12GB)
    # ────────────────────────
    'img_size'        : 640,
    'num_classes'     : 7,
    'num_anchors'     : 3,
    'epochs'          : 100,
    'lr'              : 1e-3,
    'lr_min'          : 1e-5,
    'warmup_epochs'   : 5,
    'weight_decay'    : 1e-4,
    'grad_accum'      : 4,     # effective batch = batch_size × grad_accum
    'use_fp16'        : True,
    'num_workers'     : 2,
    'save_every'      : 10,    # checkpoint every N epochs
    'lambda_box'      : 5.0,
    'lambda_obj'      : 1.0,
    'lambda_cls'      : 0.5,
    'conf_thresh'     : 0.25,
    'iou_thresh'      : 0.45,
}

# Anchors — clustered from DocLayNet ground-truth (normalized to 640)
ANCHORS = [
    [(0.04,0.02),(0.07,0.04),(0.10,0.06)],   # P3 — small
    [(0.15,0.05),(0.25,0.08),(0.40,0.10)],   # P4 — medium
    [(0.50,0.07),(0.70,0.15),(0.90,0.30)],   # P5 — large
]

CLS_NAMES = ['Caption','List-item','Picture','Section-header','Table','Text','Title']


# ═══════════════════════════════════════════
# 1. MODEL ARCHITECTURE
# ═══════════════════════════════════════════

class ConvBNReLU(nn.Module):
    def __init__(self, in_ch, out_ch, k=3, s=1, p=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, k, s, p, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
    def forward(self, x): return self.block(x)


class ResBlock(nn.Module):
    """Bottleneck residual block: squeeze → 3x3 → expand + skip."""
    def __init__(self, ch):
        super().__init__()
        mid = ch // 2
        self.net = nn.Sequential(
            ConvBNReLU(ch, mid, k=1, p=0),
            ConvBNReLU(mid, mid, k=3, p=1),
            nn.Conv2d(mid, ch, 1, bias=False),
            nn.BatchNorm2d(ch)
        )
        self.act = nn.ReLU(inplace=True)
    def forward(self, x): return self.act(self.net(x) + x)


class Backbone(nn.Module):
    """
    5-stage backbone: 640→320→160→80(P3)→40(P4)→20(P5)
    Total params: ~6.3M
    """
    def __init__(self):
        super().__init__()
        self.s1 = ConvBNReLU(3,   32,  s=2)                          # 320×320
        self.s2 = nn.Sequential(ConvBNReLU(32, 64, s=2),             # 160×160
                                 ResBlock(64), ResBlock(64), ResBlock(64))
        self.s3 = nn.Sequential(ConvBNReLU(64, 128, s=2),            # 80×80 → P3
                                 ResBlock(128), ResBlock(128), ResBlock(128))
        self.s4 = nn.Sequential(ConvBNReLU(128, 256, s=2),           # 40×40 → P4
                                 ResBlock(256), ResBlock(256), ResBlock(256))
        self.s5 = nn.Sequential(ConvBNReLU(256, 512, s=2),           # 20×20 → P5
                                 ResBlock(512), ResBlock(512))

    def forward(self, x):
        x  = self.s1(x)
        x  = self.s2(x)
        p3 = self.s3(x)    # 80×80×128
        p4 = self.s4(p3)   # 40×40×256
        p5 = self.s5(p4)   # 20×20×512
        return p3, p4, p5


class FPN(nn.Module):
    """Top-down FPN: fuses P5→P4→P3, all outputs 128ch."""
    def __init__(self):
        super().__init__()
        self.lat5  = ConvBNReLU(512, 128, k=1, p=0)
        self.lat4  = ConvBNReLU(256, 128, k=1, p=0)
        self.lat3  = ConvBNReLU(128, 128, k=1, p=0)
        self.fuse4 = ConvBNReLU(256, 128)
        self.fuse3 = ConvBNReLU(256, 128)

    def forward(self, p3, p4, p5):
        p5_out = self.lat5(p5)                                          # 20×20
        p4_out = self.fuse4(torch.cat([self.lat4(p4),
                             F.interpolate(p5_out, scale_factor=2,
                                           mode='nearest')], 1))        # 40×40
        p3_out = self.fuse3(torch.cat([self.lat3(p3),
                             F.interpolate(p4_out, scale_factor=2,
                                           mode='nearest')], 1))        # 80×80
        return p3_out, p4_out, p5_out


class DetHead(nn.Module):
    """Per-scale detection head → (B, A*(5+C), H, W)"""
    def __init__(self, in_ch=128, num_anchors=3, num_classes=7):
        super().__init__()
        out = num_anchors * (5 + num_classes)
        self.head = nn.Sequential(
            ConvBNReLU(in_ch, in_ch * 2),
            nn.Conv2d(in_ch * 2, out, 1)
        )
    def forward(self, x): return self.head(x)


class DocumentLayoutModel(nn.Module):
    def __init__(self, num_classes=7, num_anchors=3):
        super().__init__()
        self.backbone = Backbone()
        self.neck     = FPN()
        self.head_s   = DetHead(128, num_anchors, num_classes)  # small  P3
        self.head_m   = DetHead(128, num_anchors, num_classes)  # medium P4
        self.head_l   = DetHead(128, num_anchors, num_classes)  # large  P5

    def forward(self, x):
        p3, p4, p5 = self.backbone(x)
        f3, f4, f5 = self.neck(p3, p4, p5)
        return self.head_s(f3), self.head_m(f4), self.head_l(f5)

    def count_params(self):
        n = sum(p.numel() for p in self.parameters())
        print(f"Total parameters: {n/1e6:.2f}M")
        return n


# ═══════════════════════════════════════════
# 2. LOSS FUNCTION
# ═══════════════════════════════════════════

def ciou_loss(pred_boxes, target_boxes):
    """CIoU loss between (N,4) tensors in [x1,y1,x2,y2] format."""
    px1,py1,px2,py2 = pred_boxes[:,0],pred_boxes[:,1],pred_boxes[:,2],pred_boxes[:,3]
    tx1,ty1,tx2,ty2 = target_boxes[:,0],target_boxes[:,1],target_boxes[:,2],target_boxes[:,3]

    inter_x1 = torch.max(px1, tx1)
    inter_y1 = torch.max(py1, ty1)
    inter_x2 = torch.min(px2, tx2)
    inter_y2 = torch.min(py2, ty2)
    inter    = (inter_x2-inter_x1).clamp(0) * (inter_y2-inter_y1).clamp(0)

    area_p   = (px2-px1).clamp(0) * (py2-py1).clamp(0)
    area_t   = (tx2-tx1).clamp(0) * (ty2-ty1).clamp(0)
    union    = area_p + area_t - inter + 1e-7
    iou      = inter / union

    # Enclosing box diagonal
    enc_x1, enc_x2 = torch.min(px1,tx1), torch.max(px2,tx2)
    enc_y1, enc_y2 = torch.min(py1,ty1), torch.max(py2,ty2)
    c2       = (enc_x2-enc_x1)**2 + (enc_y2-enc_y1)**2 + 1e-7

    # Center distance
    cx_p = (px1+px2)/2; cy_p = (py1+py2)/2
    cx_t = (tx1+tx2)/2; cy_t = (ty1+ty2)/2
    rho2 = (cx_p-cx_t)**2 + (cy_p-cy_t)**2

    # Aspect ratio consistency
    w_p = (px2-px1).clamp(1e-7); h_p = (py2-py1).clamp(1e-7)
    w_t = (tx2-tx1).clamp(1e-7); h_t = (ty2-ty1).clamp(1e-7)
    v    = (4/math.pi**2) * (torch.atan(w_t/h_t) - torch.atan(w_p/h_p))**2
    with torch.no_grad():
        alpha = v / (1 - iou + v + 1e-7)

    ciou = iou - rho2/c2 - alpha*v
    return (1 - ciou).mean()


class YOLOLoss(nn.Module):
    def __init__(self, anchors, num_classes=7, img_size=640,
                 lambda_box=5.0, lambda_obj=1.0, lambda_cls=0.5):
        super().__init__()
        self.anchors     = anchors
        self.nc          = num_classes
        self.img_size    = img_size
        self.lambda_box  = lambda_box
        self.lambda_obj  = lambda_obj
        self.lambda_cls  = lambda_cls
        self.bce         = nn.BCEWithLogitsLoss()
        self.ce          = nn.CrossEntropyLoss()

    def forward(self, preds, targets, device):
        """
        preds:   tuple of 3 tensors (B, A*(5+C), H, W)
        targets: list of tensors, each (num_boxes, 6) = [img_idx, cls, xc, yc, w, h]
        """
        total_box = torch.tensor(0., device=device)
        total_obj = torch.tensor(0., device=device)
        total_cls = torch.tensor(0., device=device)

        for scale_i, pred in enumerate(preds):
            B, _, H, W = pred.shape
            A  = len(self.anchors[scale_i])
            nc = self.nc
            # Reshape: (B, A, H, W, 5+nc)
            pred = pred.view(B, A, 5+nc, H, W).permute(0,1,3,4,2).contiguous()

            anch = torch.tensor(self.anchors[scale_i], device=device)  # (A,2)

            # Build targets for this scale
            obj_mask   = torch.zeros(B, A, H, W, device=device)
            noobj_mask = torch.ones(B, A, H, W, device=device)
            tx_t = torch.zeros(B, A, H, W, device=device)
            ty_t = torch.zeros(B, A, H, W, device=device)
            tw_t = torch.zeros(B, A, H, W, device=device)
            th_t = torch.zeros(B, A, H, W, device=device)
            cls_t= torch.zeros(B, A, H, W, dtype=torch.long, device=device)

            for t in targets:
                if t is None or len(t) == 0:
                    continue
                for box in t:
                    img_i, cls, xc, yc, bw, bh = box
                    img_i = int(img_i)
                    gi = int(xc * W)
                    gj = int(yc * H)
                    gi = min(gi, W-1); gj = min(gj, H-1)

                    # Pick best anchor by IoU on shape
                    wh = torch.tensor([[bw, bh]], device=device)
                    anch_wh  = anch  # (A,2)
                    inter    = torch.min(wh, anch_wh).prod(1)
                    union    = (wh.prod(1) + anch_wh.prod(1) - inter)
                    iou_anch = inter / union.clamp(1e-7)
                    best_a   = iou_anch.argmax().item()

                    obj_mask  [img_i, best_a, gj, gi] = 1
                    noobj_mask[img_i, best_a, gj, gi] = 0
                    tx_t[img_i, best_a, gj, gi] = xc * W - gi
                    ty_t[img_i, best_a, gj, gi] = yc * H - gj
                    tw_t[img_i, best_a, gj, gi] = bw / (anch[best_a,0] + 1e-7)
                    th_t[img_i, best_a, gj, gi] = bh / (anch[best_a,1] + 1e-7)
                    cls_t[img_i, best_a, gj, gi] = int(cls)

            mask = obj_mask.bool()

            # Box loss (CIoU) on positive cells
            if mask.any():
                pred_xy = torch.sigmoid(pred[..., :2])
                pred_wh = pred[..., 2:4]
                pred_conf= pred[..., 4]

                # Decode to image coords for CIoU
                gx, gy = torch.meshgrid(torch.arange(W,device=device),
                                         torch.arange(H,device=device), indexing='xy')
                grid   = torch.stack([gx,gy],-1).float().unsqueeze(0).unsqueeze(0) # (1,1,H,W,2)
                px  = (pred_xy[...,0][mask] + grid[...,0].expand(B,A,H,W)[mask]) / W
                py  = (pred_xy[...,1][mask] + grid[...,1].expand(B,A,H,W)[mask]) / H
                aw  = anch[:,0].view(1,A,1,1).expand(B,A,H,W)[mask]
                ah  = anch[:,1].view(1,A,1,1).expand(B,A,H,W)[mask]
                pw  = torch.exp(pred_wh[...,0][mask].clamp(-4,4)) * aw
                ph  = torch.exp(pred_wh[...,1][mask].clamp(-4,4)) * ah

                tx = tx_t[mask]; ty = ty_t[mask]
                tw = tw_t[mask] * aw; th = th_t[mask] * ah

                pred_xyxy = torch.stack([px-pw/2, py-ph/2, px+pw/2, py+ph/2], -1)
                targ_x    = (tx_t[mask] + grid[...,0].expand(B,A,H,W)[mask]) / W
                targ_y    = (ty_t[mask] + grid[...,1].expand(B,A,H,W)[mask]) / H
                targ_xyxy = torch.stack([targ_x-tw/2, targ_y-th/2,
                                          targ_x+tw/2, targ_y+th/2], -1)
                total_box = total_box + ciou_loss(pred_xyxy, targ_xyxy)

                # Class loss
                total_cls = total_cls + self.ce(
                    pred[..., 5:][mask], cls_t[mask])

            # Objectness loss
            total_obj = total_obj + self.bce(pred[...,4], obj_mask)

        loss = (self.lambda_box * total_box +
                self.lambda_obj * total_obj +
                self.lambda_cls * total_cls)
        return loss, total_box.item(), total_obj.item(), total_cls.item()


# ═══════════════════════════════════════════
# 3. DATASET
# ═══════════════════════════════════════════

class YOLODataset(Dataset):
    IMG_MEAN = [0.485, 0.456, 0.406]
    IMG_STD  = [0.229, 0.224, 0.225]

    def __init__(self, data_root, split, img_size=640, augment=True):
        self.img_size  = img_size
        self.augment   = augment
        self.imgs      = []
        self.labels    = []

        img_dir = Path(data_root) / split / 'images'
        lbl_dir = Path(data_root) / split / 'labels'

        for img_path in sorted(img_dir.glob('*.jpg')) + sorted(img_dir.glob('*.png')):
            lbl_path = lbl_dir / (img_path.stem + '.txt')
            self.imgs.append(img_path)
            self.labels.append(lbl_path)

        self.transform = self._build_transforms(augment)
        print(f"  {split}: {len(self.imgs)} images loaded")

    def _build_transforms(self, augment):
        if augment:
            return A.Compose([
                A.LongestMaxSize(self.img_size),
                A.PadIfNeeded(self.img_size, self.img_size,
                              border_mode=0, value=(114,114,114)),
                A.ColorJitter(brightness=0.3, contrast=0.3,
                              saturation=0.1, hue=0.0, p=0.5),
                A.Rotate(limit=5, border_mode=0, p=0.3),
                A.RandomScale(scale_limit=0.3, p=0.5),
                A.Normalize(mean=self.IMG_MEAN, std=self.IMG_STD),
                ToTensorV2(),
            ], bbox_params=A.BboxParams(format='yolo',
                                        label_fields=['labels'],
                                        min_visibility=0.3))
        else:
            return A.Compose([
                A.LongestMaxSize(self.img_size),
                A.PadIfNeeded(self.img_size, self.img_size,
                              border_mode=0, value=(114,114,114)),
                A.Normalize(mean=self.IMG_MEAN, std=self.IMG_STD),
                ToTensorV2(),
            ], bbox_params=A.BboxParams(format='yolo',
                                        label_fields=['labels'],
                                        min_visibility=0.3))

    def __len__(self):
        return len(self.imgs)

    def __getitem__(self, idx):
        img    = np.array(Image.open(self.imgs[idx]).convert('RGB'))
        bboxes = []
        labels = []
        lbl_path = self.labels[idx]
        if lbl_path.exists():
            for line in lbl_path.read_text().strip().split('\n'):
                if not line.strip(): continue
                cls, xc, yc, w, h = map(float, line.split())
                bboxes.append([xc, yc, w, h])
                labels.append(int(cls))
        try:
            result = self.transform(image=img, bboxes=bboxes, labels=labels)
        except Exception:
            result = {'image': torch.zeros(3, self.img_size, self.img_size),
                      'bboxes': [], 'labels': []}
        boxes_out = torch.tensor(result['bboxes'], dtype=torch.float32) \
            if result['bboxes'] else torch.zeros((0, 4))
        cls_out   = torch.tensor(result['labels'], dtype=torch.float32) \
            if result['labels'] else torch.zeros((0,))
        # Stack into (N, 6): [img_idx, cls, xc, yc, w, h]
        if len(boxes_out):
            target = torch.cat([torch.zeros(len(boxes_out),1),
                                 cls_out.unsqueeze(1), boxes_out], dim=1)
        else:
            target = torch.zeros((0, 6))
        return result['image'], target


def collate_fn(batch):
    imgs, targets = zip(*batch)
    imgs = torch.stack(imgs)
    for i, t in enumerate(targets):
        if len(t): t[:, 0] = i
    return imgs, list(targets)


# ═══════════════════════════════════════════
# 4. TRAINING
# ═══════════════════════════════════════════

def print_vram(label=''):
    if torch.cuda.is_available():
        a = torch.cuda.memory_allocated()/1e9
        r = torch.cuda.memory_reserved()/1e9
        t = torch.cuda.get_device_properties(0).total_memory/1e9
        print(f"VRAM {label}: {a:.2f}GB used / {r:.2f}GB reserved / {t:.2f}GB total")


def train():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(CHECKPT_DIR, exist_ok=True)
    os.makedirs(LOG_DIR, exist_ok=True)

    data_root = str(Path(DATA_YAML).parent)

    # ── Model ──
    model = DocumentLayoutModel(CFG['num_classes'], CFG['num_anchors']).to(device)
    model.count_params()
    print_vram('after model init')

    # ── Optim + Schedule ──
    optimizer = optim.AdamW(model.parameters(),
                            lr=CFG['lr'], weight_decay=CFG['weight_decay'])

    def lr_lambda(epoch):
        if epoch < CFG['warmup_epochs']:
            return max(0.01, epoch / CFG['warmup_epochs'])
        t = (epoch - CFG['warmup_epochs']) / max(1, CFG['epochs'] - CFG['warmup_epochs'])
        return CFG['lr_min']/CFG['lr'] + 0.5*(1-CFG['lr_min']/CFG['lr'])*(1+math.cos(math.pi*t))

    scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    scaler    = GradScaler(enabled=CFG['use_fp16'])
    criterion = YOLOLoss(ANCHORS, CFG['num_classes'], CFG['img_size'],
                          CFG['lambda_box'], CFG['lambda_obj'], CFG['lambda_cls']).to(device)

    # ── Data ──
    train_ds = YOLODataset(data_root, 'train', CFG['img_size'], augment=True)
    val_ds   = YOLODataset(data_root, 'val',   CFG['img_size'], augment=False)
    train_dl = DataLoader(train_ds, batch_size=CFG['batch_size'], shuffle=True,
                          num_workers=CFG['num_workers'], pin_memory=True,
                          collate_fn=collate_fn, drop_last=True)
    val_dl   = DataLoader(val_ds, batch_size=CFG['batch_size'], shuffle=False,
                          num_workers=CFG['num_workers'], collate_fn=collate_fn)

    # ── Resume from checkpoint ──
    start_epoch = 1
    ckpt_files  = sorted(Path(CHECKPT_DIR).glob('epoch_*.pt'))
    if ckpt_files:
        latest = ckpt_files[-1]
        ckpt   = torch.load(latest, map_location=device)
        model.load_state_dict(ckpt['model'])
        optimizer.load_state_dict(ckpt['optimizer'])
        start_epoch = ckpt['epoch'] + 1
        print(f"Resumed from {latest.name} — starting epoch {start_epoch}")

    history = defaultdict(list)
    best_loss = float('inf')

    for epoch in range(start_epoch, CFG['epochs'] + 1):
        # ─── TRAIN ───
        model.train()
        epoch_loss = 0.; box_l = 0.; obj_l = 0.; cls_l = 0.
        optimizer.zero_grad()
        t0 = time.time()

        for step, (imgs, targets) in enumerate(train_dl):
            imgs = imgs.to(device)

            with autocast(enabled=CFG['use_fp16']):
                preds = model(imgs)
                loss, b, o, c = criterion(preds, targets, device)
                loss = loss / CFG['grad_accum']

            scaler.scale(loss).backward()

            if (step + 1) % CFG['grad_accum'] == 0:
                scaler.unscale_(optimizer)
                nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            epoch_loss += loss.item() * CFG['grad_accum']
            box_l += b; obj_l += o; cls_l += c

        scheduler.step()
        n    = len(train_dl)
        lr_  = optimizer.param_groups[0]['lr']
        et   = time.time() - t0

        print(f"Ep {epoch:3d}/{CFG['epochs']} | "
              f"Loss {epoch_loss/n:.4f} (box:{box_l/n:.3f} "
              f"obj:{obj_l/n:.3f} cls:{cls_l/n:.3f}) | "
              f"LR {lr_:.2e} | {et/60:.1f}min")
        print_vram(f'epoch {epoch}')

        history['loss'].append(epoch_loss/n)
        history['lr'].append(lr_)

        # ─── CHECKPOINT ───
        if epoch % CFG['save_every'] == 0 or epoch == CFG['epochs']:
            ckpt_path = os.path.join(CHECKPT_DIR, f'epoch_{epoch:03d}.pt')
            torch.save({
                'epoch'    : epoch,
                'model'    : model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'loss'     : epoch_loss / n,
                'cfg'      : CFG,
            }, ckpt_path)
            print(f"  💾 Saved → {ckpt_path}")

            if epoch_loss/n < best_loss:
                best_loss = epoch_loss/n
                best_path = os.path.join(CHECKPT_DIR, 'best.pt')
                shutil.copy(ckpt_path, best_path)
                print(f"  ⭐ New best → {best_path}")

    # ─── PLOT LOSS CURVE ───
    plt.figure(figsize=(10, 4))
    plt.plot(history['loss'])
    plt.xlabel('Epoch'); plt.ylabel('Loss'); plt.title('Custom 10M — Training Loss')
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(os.path.join(LOG_DIR, 'custom_10M_loss.png'), dpi=100)
    plt.show()
    print("Training complete. Best checkpoint:", best_path)
    return model


if __name__ == '__main__':
    print(f"Config: batch={CFG['batch_size']} img={CFG['img_size']} "
          f"fp16={CFG['use_fp16']} epochs={CFG['epochs']}")
    print(f"Effective batch = {CFG['batch_size'] * CFG['grad_accum']}")
    model = train()
