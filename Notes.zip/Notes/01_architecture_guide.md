# Guide 1 — Architecture Deep Dive
## Custom Document Layout Detection Model (from Scratch)

> **What you're building:** A YOLO-style object detector in raw PyTorch that takes a PDF page image (640×640) and outputs bounding boxes classified as Title, Section-header, Text, Table, Picture, List-item, Caption.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                     INPUT LAYER                             │
│              PDF Page Image — 640 × 640 × 3 RGB             │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│                    BACKBONE (Stage 1-5)                     │
│   ResNet-style CNN — Custom Feature Extractor ~6M params    │
│                                                             │
│  Stage 1:  Conv 3×3, 32ch, stride=2  → 320×320×32          │
│  Stage 2:  Conv 3×3, 64ch, stride=2  → 160×160×64          │
│            × 3 ResBlocks(64)                                │
│  Stage 3:  Conv 3×3, 128ch, stride=2 → 80×80×128    (P3)   │
│            × 3 ResBlocks(128)                               │
│  Stage 4:  Conv 3×3, 256ch, stride=2 → 40×40×256    (P4)   │
│            × 3 ResBlocks(256)                               │
│  Stage 5:  Conv 3×3, 512ch, stride=2 → 20×20×512    (P5)   │
│            × 2 ResBlocks(512)                               │
└────────┬──────────────┬──────────────┬──────────────────────┘
         │ P3 (80×80)   │ P4 (40×40)   │ P5 (20×20)
         ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────┐
│                    NECK — FPN (3 scales)                    │
│     Feature Pyramid Network — multi-scale feature fusion    │
│                                                             │
│  P5 (20×20) ──────────────────────────────────► P5_out     │
│      │ upsample 2×                                         │
│      ▼                                                      │
│  P4 (40×40) ──── concat(P5↑) ── Conv ────────► P4_out     │
│      │ upsample 2×                                         │
│      ▼                                                      │
│  P3 (80×80) ──── concat(P4↑) ── Conv ────────► P3_out     │
└────────┬──────────────┬──────────────┬──────────────────────┘
   P3_out (80×80)  P4_out (40×40)  P5_out (20×20)
   small objects   medium objects  large objects
         │              │              │
         ▼              ▼              ▼
┌─────────────────────────────────────────────────────────────┐
│              DETECTION HEAD (per scale)                     │
│                                                             │
│  Each scale:  Conv 1×1 → 3 × (5 + num_classes)            │
│               3 = number of anchors per cell               │
│               5 = [x_center, y_center, w, h, objectness]   │
│               num_classes = 7                              │
│                                                             │
│  P3 head: 80×80×3×12  → small bboxes  (list items etc.)   │
│  P4 head: 40×40×3×12  → medium bboxes (text blocks)       │
│  P5 head: 20×20×3×12  → large bboxes  (titles, tables)    │
└────────┬──────────────┬──────────────┬──────────────────────┘
         │              │              │
         └──────────────┴──────────────┘
                        │
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                 POST-PROCESSING (NMS)                       │
│  sigmoid(objectness) × sigmoid(class_prob)                  │
│  Decode anchor boxes → absolute coordinates                 │
│  Non-Maximum Suppression (IoU threshold = 0.45)            │
│  Confidence threshold = 0.25                               │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
             Final: [(x1,y1,x2,y2, class, conf), ...]
```

---

## ResBlock — The Core Building Block

```
 Input x (C channels)
    │
    ├──────────────────────────────────┐
    │                                  │ (skip / identity)
    ▼                                  │
 Conv 1×1 (C → C//2)                   │
 BatchNorm + ReLU                       │
    │                                  │
 Conv 3×3 (C//2 → C//2, pad=1)         │
 BatchNorm + ReLU                       │
    │                                  │
 Conv 1×1 (C//2 → C)                   │
 BatchNorm                              │
    │                                  │
    └──────── Add ◄────────────────────┘
              │
             ReLU
              │
           Output
```

Each ResBlock learns residual features. Stacking them lets the backbone learn rich hierarchical features without vanishing gradients.

---

## FPN — Why 3 Scales?

Document pages contain objects at wildly different sizes:
- **Small:** List-item bullets, captions → detected at P3 (80×80 grid)
- **Medium:** Text blocks, Pictures → detected at P4 (40×40 grid)
- **Large:** Full-width titles, wide tables → detected at P5 (20×20 grid)

FPN fuses high-resolution spatial info (P3) with deep semantic info (P5) via top-down upsampling + lateral connections.

---

## Anchor Boxes — What to Use for Documents

Anchors should reflect real document element proportions:

```python
# Suggested anchors (normalized to 640×640)
# Small scale (P3, 80×80 grid)
anchors_small  = [(0.04, 0.02), (0.07, 0.04), (0.10, 0.06)]
# Medium scale (P4, 40×40 grid)
anchors_medium = [(0.15, 0.05), (0.25, 0.08), (0.40, 0.10)]
# Large scale (P5, 20×20 grid)
anchors_large  = [(0.50, 0.07), (0.70, 0.15), (0.90, 0.30)]
# Format: (width, height) normalized
```

Run k-means clustering on DocLayNet ground truth boxes to get optimal anchors for your specific data.

---

## Loss Function

```
Total_Loss = λ_box × CIoU_loss
           + λ_obj × BCE_loss(objectness)
           + λ_cls × CrossEntropy_loss(class)

Weights (recommended starting point):
  λ_box = 5.0
  λ_obj = 1.0
  λ_cls = 0.5

CIoU = IoU − (ρ²(center)/c²) − α×v
  where v measures aspect ratio consistency
  and α is a trade-off weight
```

CIoU penalizes not just overlap but also center distance and aspect ratio mismatch — critical for tall/narrow document elements like titles vs wide text blocks.

---

## Parameter Count Summary

| Component | Params (approx) |
|---|---|
| Backbone (5 stages + ResBlocks) | ~6.5M |
| FPN Neck (lateral + upsample convs) | ~1.5M |
| Detection Heads (×3 scales) | ~0.5M |
| **Total** | **~8.5M** |

Fits comfortably in T4 VRAM at batch=16, fp16.

---

## Files You Will Write

```
model/
  backbone.py     ← ConvBlock, ResBlock, CustomBackbone classes
  neck.py         ← FPN class
  head.py         ← DetectionHead class
  model.py        ← DocumentLayoutModel (assembles all 3)
  loss.py         ← CIoULoss, ObjectnessLoss, total loss fn
  anchors.py      ← anchor definitions + matching logic
  nms.py          ← decode_predictions(), apply_nms()
```

---

## Next Step
See `02_dataset_guide.md` — downloading and preprocessing DocLayNet.
