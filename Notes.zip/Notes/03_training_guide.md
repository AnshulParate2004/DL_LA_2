# Guide 3 — Training on Google Colab T4
## Building the Model in PyTorch + Full Training Loop

> **Goal:** Implement the custom architecture from scratch in PyTorch, set up an efficient training loop for T4 (fp16, gradient accumulation, cosine LR), and save checkpoints to Google Drive.

---

## Colab Setup

```python
# Cell 1 — Mount Drive + Install deps
from google.colab import drive
drive.mount('/content/drive')

!pip install torch torchvision albumentations tqdm matplotlib -q

import torch
print(f"PyTorch: {torch.__version__}")
print(f"CUDA:    {torch.cuda.is_available()}")
print(f"GPU:     {torch.cuda.get_device_name(0)}")
print(f"VRAM:    {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
```

---

## Step 1 — Build the Model

### backbone.py

```python
import torch
import torch.nn as nn

class ConvBNReLU(nn.Module):
    """Conv + BatchNorm + ReLU — used everywhere."""
    def __init__(self, in_ch, out_ch, kernel=3, stride=1, padding=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel, stride, padding, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True)
        )
    def forward(self, x):
        return self.block(x)


class ResBlock(nn.Module):
    """Bottleneck residual block: 1×1 → 3×3 → 1×1 with skip connection."""
    def __init__(self, channels):
        super().__init__()
        mid = channels // 2
        self.conv1 = ConvBNReLU(channels, mid, kernel=1, padding=0)
        self.conv2 = ConvBNReLU(mid, mid, kernel=3, padding=1)
        self.conv3 = nn.Sequential(
            nn.Conv2d(mid, channels, 1, bias=False),
            nn.BatchNorm2d(channels)
        )
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        residual = x
        out = self.conv1(x)
        out = self.conv2(out)
        out = self.conv3(out)
        return self.relu(out + residual)


class CustomBackbone(nn.Module):
    """
    5-stage ResNet-style backbone.
    Returns P3 (80×80), P4 (40×40), P5 (20×20) feature maps.
    """
    def __init__(self):
        super().__init__()
        # Stage 1: 640×640 → 320×320
        self.stage1 = ConvBNReLU(3, 32, stride=2)
        # Stage 2: 320×320 → 160×160
        self.stage2 = nn.Sequential(
            ConvBNReLU(32, 64, stride=2),
            ResBlock(64), ResBlock(64), ResBlock(64)
        )
        # Stage 3: 160×160 → 80×80  (P3)
        self.stage3 = nn.Sequential(
            ConvBNReLU(64, 128, stride=2),
            ResBlock(128), ResBlock(128), ResBlock(128)
        )
        # Stage 4: 80×80 → 40×40  (P4)
        self.stage4 = nn.Sequential(
            ConvBNReLU(128, 256, stride=2),
            ResBlock(256), ResBlock(256), ResBlock(256)
        )
        # Stage 5: 40×40 → 20×20  (P5)
        self.stage5 = nn.Sequential(
            ConvBNReLU(256, 512, stride=2),
            ResBlock(512), ResBlock(512)
        )

    def forward(self, x):
        x = self.stage1(x)
        x = self.stage2(x)
        p3 = self.stage3(x)   # 80×80×128
        p4 = self.stage4(p3)  # 40×40×256
        p5 = self.stage5(p4)  # 20×20×512
        return p3, p4, p5
```

### neck.py

```python
import torch
import torch.nn as nn
import torch.nn.functional as F
from backbone import ConvBNReLU

class FPN(nn.Module):
    """
    Feature Pyramid Network — top-down pathway with lateral connections.
    Input:  P3 (80×80×128), P4 (40×40×256), P5 (20×20×512)
    Output: P3_out (80×80×128), P4_out (40×40×128), P5_out (20×20×128)
    """
    def __init__(self):
        super().__init__()
        # Lateral convs: reduce channels to 128 everywhere
        self.lateral5 = ConvBNReLU(512, 128, kernel=1, padding=0)
        self.lateral4 = ConvBNReLU(256, 128, kernel=1, padding=0)
        self.lateral3 = ConvBNReLU(128, 128, kernel=1, padding=0)

        # Top-down fusion convs (after concat)
        self.fuse4 = ConvBNReLU(256, 128, kernel=3)  # 128 + 128 after concat
        self.fuse3 = ConvBNReLU(256, 128, kernel=3)

    def forward(self, p3, p4, p5):
        # Top level
        p5_out = self.lateral5(p5)                         # 20×20×128

        # Middle level
        p5_up  = F.interpolate(p5_out, scale_factor=2, mode='nearest')  # 40×40
        p4_lat = self.lateral4(p4)
        p4_out = self.fuse4(torch.cat([p4_lat, p5_up], dim=1))          # 40×40×128

        # Bottom level
        p4_up  = F.interpolate(p4_out, scale_factor=2, mode='nearest')  # 80×80
        p3_lat = self.lateral3(p3)
        p3_out = self.fuse3(torch.cat([p3_lat, p4_up], dim=1))          # 80×80×128

        return p3_out, p4_out, p5_out
```

### head.py

```python
import torch.nn as nn
from backbone import ConvBNReLU

class DetectionHead(nn.Module):
    """
    Per-scale detection head.
    Output shape: (B, num_anchors*(5+num_classes), H, W)
    """
    def __init__(self, in_channels=128, num_anchors=3, num_classes=7):
        super().__init__()
        out_ch = num_anchors * (5 + num_classes)  # 3*(5+7) = 36
        self.head = nn.Sequential(
            ConvBNReLU(in_channels, in_channels * 2),
            nn.Conv2d(in_channels * 2, out_ch, kernel_size=1)
        )

    def forward(self, x):
        return self.head(x)
```

### model.py

```python
import torch.nn as nn
from backbone import CustomBackbone
from neck import FPN
from head import DetectionHead

class DocumentLayoutModel(nn.Module):
    def __init__(self, num_classes=7, num_anchors=3):
        super().__init__()
        self.backbone = CustomBackbone()
        self.neck     = FPN()
        self.head_s   = DetectionHead(128, num_anchors, num_classes)  # P3 small
        self.head_m   = DetectionHead(128, num_anchors, num_classes)  # P4 medium
        self.head_l   = DetectionHead(128, num_anchors, num_classes)  # P5 large

    def forward(self, x):
        p3, p4, p5 = self.backbone(x)
        p3_out, p4_out, p5_out = self.neck(p3, p4, p5)
        return (
            self.head_s(p3_out),   # (B, 36, 80, 80)
            self.head_m(p4_out),   # (B, 36, 40, 40)
            self.head_l(p5_out),   # (B, 36, 20, 20)
        )

# Quick sanity check
if __name__ == '__main__':
    import torch
    model = DocumentLayoutModel()
    x = torch.randn(2, 3, 640, 640)
    s, m, l = model(x)
    print(f"Small head:  {s.shape}")  # (2, 36, 80, 80)
    print(f"Medium head: {m.shape}")  # (2, 36, 40, 40)
    print(f"Large head:  {l.shape}")  # (2, 36, 20, 20)
    params = sum(p.numel() for p in model.parameters())
    print(f"Total params: {params/1e6:.2f}M")
```

---

## Step 2 — DataLoader + Augmentation

```python
import albumentations as A
from albumentations.pytorch import ToTensorV2

train_transforms = A.Compose([
    A.LongestMaxSize(max_size=640),
    A.PadIfNeeded(640, 640, border_mode=0, value=(114,114,114)),
    A.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.0, hue=0.0, p=0.5),
    A.Rotate(limit=5, border_mode=0, p=0.3),
    A.RandomScale(scale_limit=0.3, p=0.5),
    A.HorizontalFlip(p=0.0),   # DISABLED — text direction matters!
    A.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ToTensorV2(),
], bbox_params=A.BboxParams(format='yolo', label_fields=['labels'], min_visibility=0.3))

val_transforms = A.Compose([
    A.LongestMaxSize(max_size=640),
    A.PadIfNeeded(640, 640, border_mode=0, value=(114,114,114)),
    A.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ToTensorV2(),
], bbox_params=A.BboxParams(format='yolo', label_fields=['labels'], min_visibility=0.3))
```

---

## Step 3 — Training Config

```python
CONFIG = {
    'data_root':    '/content/drive/MyDrive/DocLayNet',
    'checkpoint_dir': '/content/drive/MyDrive/DL_checkpoints',
    'img_size':     640,
    'batch_size':   16,
    'num_workers':  2,
    'epochs':       100,
    'lr':           1e-3,
    'lr_min':       1e-5,
    'warmup_epochs': 3,
    'grad_accum_steps': 4,   # effective batch = 64
    'num_classes':  7,
    'num_anchors':  3,
    'use_fp16':     True,
    'save_every':   10,       # save checkpoint every N epochs
}
```

---

## Step 4 — Training Loop

```python
import torch
import torch.optim as optim
from torch.cuda.amp import autocast, GradScaler
from torch.utils.data import DataLoader
import os

def train(config):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(config['checkpoint_dir'], exist_ok=True)

    # Model
    model = DocumentLayoutModel(
        num_classes=config['num_classes'],
        num_anchors=config['num_anchors']
    ).to(device)

    # Optimizer
    optimizer = optim.AdamW(model.parameters(), lr=config['lr'], weight_decay=1e-4)

    # LR Schedule: linear warmup → cosine decay
    def lr_lambda(epoch):
        if epoch < config['warmup_epochs']:
            return epoch / max(config['warmup_epochs'], 1)
        progress = (epoch - config['warmup_epochs']) / max(config['epochs'] - config['warmup_epochs'], 1)
        return config['lr_min']/config['lr'] + 0.5*(1 - config['lr_min']/config['lr'])*(1 + __import__('math').cos(__import__('math').pi * progress))

    scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    scaler    = GradScaler(enabled=config['use_fp16'])

    # DataLoaders (assumes YOLODataset class is defined)
    train_loader = DataLoader(
        YOLODataset(config['data_root'], 'train', train_transforms),
        batch_size=config['batch_size'],
        shuffle=True,
        num_workers=config['num_workers'],
        pin_memory=True,
        collate_fn=yolo_collate_fn
    )
    val_loader = DataLoader(
        YOLODataset(config['data_root'], 'val', val_transforms),
        batch_size=config['batch_size'],
        shuffle=False,
        num_workers=config['num_workers'],
        collate_fn=yolo_collate_fn
    )

    best_map = 0.0

    for epoch in range(1, config['epochs'] + 1):
        model.train()
        total_loss = 0.0
        optimizer.zero_grad()

        for step, (images, targets) in enumerate(train_loader):
            images = images.to(device)

            with autocast(enabled=config['use_fp16']):
                preds = model(images)           # tuple of 3 scales
                loss  = compute_loss(preds, targets, device)
                loss  = loss / config['grad_accum_steps']

            scaler.scale(loss).backward()

            # Gradient accumulation
            if (step + 1) % config['grad_accum_steps'] == 0:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad()

            total_loss += loss.item() * config['grad_accum_steps']

        scheduler.step()
        avg_loss = total_loss / len(train_loader)
        lr_now   = optimizer.param_groups[0]['lr']

        print(f"Epoch {epoch:3d}/{config['epochs']} | Loss: {avg_loss:.4f} | LR: {lr_now:.6f}")

        # Save checkpoint
        if epoch % config['save_every'] == 0:
            ckpt_path = os.path.join(config['checkpoint_dir'], f"epoch_{epoch:03d}.pt")
            torch.save({
                'epoch': epoch,
                'model_state': model.state_dict(),
                'optimizer_state': optimizer.state_dict(),
                'loss': avg_loss,
            }, ckpt_path)
            print(f"   💾 Checkpoint saved → {ckpt_path}")

    print("✅ Training complete.")
    return model

model = train(CONFIG)
```

---

## Step 5 — VRAM Monitoring

```python
def print_vram():
    allocated = torch.cuda.memory_allocated() / 1e9
    reserved  = torch.cuda.memory_reserved()  / 1e9
    total     = torch.cuda.get_device_properties(0).total_memory / 1e9
    print(f"VRAM: {allocated:.2f}GB used / {reserved:.2f}GB reserved / {total:.2f}GB total")

# Call after first forward pass to verify you're in the safe zone
```

---

## If You Run Out of VRAM — Checklist

| Fix | Code change |
|---|---|
| Reduce batch size | `batch_size = 8` |
| Increase grad accum | `grad_accum_steps = 8` (keeps effective batch same) |
| Reduce image size | `img_size = 512` |
| Fewer ResBlocks | Remove 1 ResBlock per stage |
| Delete cache | `torch.cuda.empty_cache()` |
| Restart Colab runtime | Nuclear option |

---

## Next Step
See `04_inference_and_integration_guide.md` — running the trained model on PDFs and integrating with MVL-AgneticAI.
