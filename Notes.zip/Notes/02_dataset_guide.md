# Guide 2 — Dataset: DocLayNet Setup & Preprocessing

> **Goal:** Download DocLayNet from HuggingFace, filter to your 7 classes, convert from COCO format to YOLO format, and create a 10K-page subset for fast Colab iteration.

---

## What is DocLayNet?

| Property | Value |
|---|---|
| Source | IBM Research 2022 |
| Total pages | 80,863 annotated PDF page images |
| Annotation format | COCO JSON (bounding boxes) |
| Full 11 classes | Title, Section-header, Text, Table, Picture, Caption, List-item, Page-header, Page-footer, Footnote, Formula |
| **Your 7 classes** | Title, Section-header, Text, Table, Picture, Caption, List-item |
| License | CC BY 4.0 (free for research) |
| HuggingFace | `ds4sd/DocLayNet` |

---

## Step 1 — Download from HuggingFace

```python
# In Colab — run this first
!pip install datasets huggingface_hub

from huggingface_hub import snapshot_download

# Downloads ~28GB — run overnight or use subset approach below
snapshot_download(
    repo_id="ds4sd/DocLayNet",
    repo_type="dataset",
    local_dir="/content/drive/MyDrive/DocLayNet"
)
```

### Faster Alternative — Stream + Save Subset

```python
from datasets import load_dataset
import json, os
from PIL import Image

# Stream dataset — doesn't download everything upfront
ds = load_dataset("ds4sd/DocLayNet", split="train", streaming=True)

# Save first 10,000 pages
os.makedirs("/content/drive/MyDrive/DocLayNet/images/train", exist_ok=True)
os.makedirs("/content/drive/MyDrive/DocLayNet/labels/train", exist_ok=True)

for i, sample in enumerate(ds):
    if i >= 10_000:
        break
    # sample keys: 'image', 'image_id', 'width', 'height', 'annotations'
    img: Image.Image = sample['image']
    img.save(f"/content/drive/MyDrive/DocLayNet/images/train/{i:06d}.jpg")
    # annotations saved separately in conversion step
    print(f"\rSaved {i+1}/10000", end="")
```

---

## Step 2 — Understand COCO Format

DocLayNet ships as COCO JSON. Each annotation looks like:

```json
{
  "id": 1234,
  "image_id": 42,
  "category_id": 1,
  "bbox": [x_min, y_min, width, height],
  "area": 5600,
  "iscrowd": 0
}
```

Categories in DocLayNet:
```json
[
  {"id": 1,  "name": "Caption"},
  {"id": 2,  "name": "Footnote"},
  {"id": 3,  "name": "Formula"},
  {"id": 4,  "name": "List-item"},
  {"id": 5,  "name": "Page-footer"},
  {"id": 6,  "name": "Page-header"},
  {"id": 7,  "name": "Picture"},
  {"id": 8,  "name": "Section-header"},
  {"id": 9,  "name": "Table"},
  {"id": 10, "name": "Text"},
  {"id": 11, "name": "Title"}
]
```

---

## Step 3 — COCO → YOLO Format Conversion

YOLO format: one `.txt` file per image, one line per box:
```
<class_id> <x_center> <y_center> <width> <height>
# all values normalized to [0, 1] relative to image dimensions
```

```python
import json
import os
from pathlib import Path

# === CONFIG ===
COCO_JSON_PATH = "/content/drive/MyDrive/DocLayNet/COCO/train.json"
OUT_LABELS_DIR = "/content/drive/MyDrive/DocLayNet/labels/train/"
IMAGES_DIR     = "/content/drive/MyDrive/DocLayNet/images/train/"

# Your 7 classes → new 0-indexed class IDs for YOLO
KEEP_CLASSES = {
    1:  0,   # Caption        → class 0
    4:  1,   # List-item      → class 1
    7:  2,   # Picture        → class 2
    8:  3,   # Section-header → class 3
    9:  4,   # Table          → class 4
    10: 5,   # Text           → class 5
    11: 6,   # Title          → class 6
}
# Dropped: Footnote(2), Formula(3), Page-footer(5), Page-header(6)

def coco_to_yolo(coco_json_path: str, out_labels_dir: str):
    os.makedirs(out_labels_dir, exist_ok=True)
    
    with open(coco_json_path) as f:
        coco = json.load(f)
    
    # Build image lookup: image_id → (filename, width, height)
    images = {img['id']: img for img in coco['images']}
    
    # Group annotations by image_id
    ann_by_image = {}
    for ann in coco['annotations']:
        img_id = ann['image_id']
        ann_by_image.setdefault(img_id, []).append(ann)
    
    converted = 0
    skipped   = 0
    
    for img_id, img_info in images.items():
        W = img_info['width']
        H = img_info['height']
        filename = Path(img_info['file_name']).stem  # no extension
        
        annotations = ann_by_image.get(img_id, [])
        yolo_lines = []
        
        for ann in annotations:
            cat_id = ann['category_id']
            if cat_id not in KEEP_CLASSES:
                skipped += 1
                continue
            
            yolo_class = KEEP_CLASSES[cat_id]
            x_min, y_min, w, h = ann['bbox']
            
            # Convert to YOLO normalized format
            x_center = (x_min + w / 2) / W
            y_center  = (y_min + h / 2) / H
            w_norm    = w / W
            h_norm    = h / H
            
            # Clamp to [0,1] — some annotations slightly exceed image bounds
            x_center = min(max(x_center, 0.0), 1.0)
            y_center  = min(max(y_center,  0.0), 1.0)
            w_norm    = min(max(w_norm,    0.001), 1.0)
            h_norm    = min(max(h_norm,    0.001), 1.0)
            
            yolo_lines.append(
                f"{yolo_class} {x_center:.6f} {y_center:.6f} {w_norm:.6f} {h_norm:.6f}"
            )
        
        # Write label file (even if empty — YOLO expects a file per image)
        label_path = os.path.join(out_labels_dir, f"{filename}.txt")
        with open(label_path, 'w') as f:
            f.write('\n'.join(yolo_lines))
        
        converted += 1
    
    print(f"✅ Converted: {converted} images")
    print(f"   Skipped annotations (filtered classes): {skipped}")

coco_to_yolo(COCO_JSON_PATH, OUT_LABELS_DIR)
```

---

## Step 4 — Directory Structure After Conversion

```
DocLayNet/
├── images/
│   ├── train/      ← 69,375 JPG images (or your 10K subset)
│   ├── val/        ← 6,489 JPG images
│   └── test/       ← 4,999 JPG images
├── labels/
│   ├── train/      ← matching .txt files (YOLO format)
│   ├── val/
│   └── test/
└── dataset.yaml    ← dataset config (see below)
```

### dataset.yaml

```yaml
path: /content/drive/MyDrive/DocLayNet
train: images/train
val:   images/val
test:  images/test

nc: 7
names:
  0: Caption
  1: List-item
  2: Picture
  3: Section-header
  4: Table
  5: Text
  6: Title
```

---

## Step 5 — Create 10K Subset for Fast Iteration

```python
import os, shutil, random
from pathlib import Path

def create_subset(src_images, src_labels, dst_images, dst_labels, n=10_000, seed=42):
    os.makedirs(dst_images, exist_ok=True)
    os.makedirs(dst_labels, exist_ok=True)
    
    all_images = list(Path(src_images).glob("*.jpg"))
    random.seed(seed)
    selected = random.sample(all_images, min(n, len(all_images)))
    
    for img_path in selected:
        lbl_path = Path(src_labels) / (img_path.stem + ".txt")
        shutil.copy(img_path, dst_images)
        if lbl_path.exists():
            shutil.copy(lbl_path, dst_labels)
    
    print(f"✅ Subset created: {len(selected)} images + labels")

create_subset(
    src_images="/content/drive/MyDrive/DocLayNet/images/train",
    src_labels="/content/drive/MyDrive/DocLayNet/labels/train",
    dst_images="/content/drive/MyDrive/DocLayNet/images/train_subset",
    dst_labels="/content/drive/MyDrive/DocLayNet/labels/train_subset",
    n=10_000
)
```

---

## Step 6 — Verify Your Dataset

```python
import random
from pathlib import Path
from PIL import Image, ImageDraw

CLASS_NAMES = ['Caption','List-item','Picture','Section-header','Table','Text','Title']
COLORS = ['#FF6B6B','#4ECDC4','#45B7D1','#96CEB4','#FFEAA7','#DDA0DD','#FF8C00']

def visualize_sample(images_dir, labels_dir, n=3):
    imgs = list(Path(images_dir).glob("*.jpg"))
    for img_path in random.sample(imgs, n):
        img = Image.open(img_path).convert('RGB')
        W, H = img.size
        draw = ImageDraw.Draw(img)
        
        lbl = Path(labels_dir) / (img_path.stem + ".txt")
        if lbl.exists():
            for line in lbl.read_text().strip().split('\n'):
                if not line: continue
                cls, xc, yc, w, h = map(float, line.split())
                cls = int(cls)
                x1 = (xc - w/2) * W
                y1 = (yc - h/2) * H
                x2 = (xc + w/2) * W
                y2 = (yc + h/2) * H
                draw.rectangle([x1,y1,x2,y2], outline=COLORS[cls], width=2)
                draw.text((x1, y1), CLASS_NAMES[cls], fill=COLORS[cls])
        
        img.show()
        print(f"Image: {img_path.name} | Size: {W}×{H}")

visualize_sample(
    "/content/drive/MyDrive/DocLayNet/images/train_subset",
    "/content/drive/MyDrive/DocLayNet/labels/train_subset"
)
```

---

## Class Distribution Check

```python
from collections import Counter
from pathlib import Path

def class_distribution(labels_dir):
    counts = Counter()
    for lbl in Path(labels_dir).glob("*.txt"):
        for line in lbl.read_text().strip().split('\n'):
            if line:
                cls = int(line.split()[0])
                counts[cls] += 1
    
    CLASS_NAMES = ['Caption','List-item','Picture','Section-header','Table','Text','Title']
    print("Class Distribution:")
    total = sum(counts.values())
    for i, name in enumerate(CLASS_NAMES):
        c = counts.get(i, 0)
        print(f"  {name:20s}: {c:6d}  ({100*c/total:.1f}%)")

class_distribution("/content/drive/MyDrive/DocLayNet/labels/train_subset")
```

---

## Next Step
See `03_training_guide.md` — building the model in PyTorch and training on Colab T4.
