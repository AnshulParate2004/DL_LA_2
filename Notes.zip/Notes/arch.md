# ML Research — Custom Document Layout Model
## Replacing Unstructured.io with a DL Model Trained from Scratch

> **Goal:** Build a DL model that takes a PDF page image as input and outputs bounding boxes classified by type (Title, Section-header, Text, Table, Image) — then use title/section-header detections to chunk the document by section.
>
> **Constraint:** Must train and run on free Google Colab T4 GPU (16GB VRAM).

---

## 1. What is Unstructured.io Actually Doing?

Before building a replacement, you need to know exactly what you're replacing.

When you call `UnstructuredService.parse_pdf()`, it runs this pipeline internally:

```
PDF Page (rendered as image)
        │
        ▼
  [Document Layout Analysis]
  Detect regions + classify each one:
    • Title
    • Section-header
    • Text / NarrativeText
    • Table
    • Image / Figure
    • List-item
    • Page-header / Page-footer
    • Caption
        │
        ▼
  [Reading Order Detection]
  Sort detected blocks by reading order
  (top-to-bottom, left-to-right, multi-column aware)
        │
        ▼
  [OCR / Text Extraction]
  For text regions → extract text (from PDF directly or via OCR)
  For image regions → extract as base64 PNG
  For table regions → extract as HTML
        │
        ▼
  [Output]
  List of typed elements with metadata:
    { type, text, page_number, coordinates }
```

**The core ML task is step 1: Document Layout Analysis (DLA).**
Everything else (OCR, reading order) can be handled with rules + PyMuPDF.

---

## 2. The Exact ML Task You Need to Solve

**Input:** PDF page rendered as an RGB image (e.g. 640×640 or 1024×1024 px)

**Output:** A set of bounding boxes, each with:
- `(x_center, y_center, width, height)` — normalized coordinates
- `class` — one of: `Title`, `Section-header`, `Text`, `Table`, `Picture`, `List-item`, `Caption`, etc.

**How you use the output to chunk by title:**
```
1. For each page, render as image
2. Run model → get detected boxes
3. Collect all "Title" and "Section-header" boxes across all pages
4. Sort by (page_number, y_position)  →  reading order of titles
5. Each title defines the start of a new section/chunk
6. All Text/Table/Image boxes between two consecutive titles
   belong to that section
```

This is a standard **object detection** problem applied to document images.

---

## 3. The Dataset — DocLayNet

**DocLayNet** (IBM Research, 2022) is the best dataset for this task.

| Property | Value |
|---|---|
| Total pages | 80,863 annotated PDF pages |
| Format | COCO JSON (bounding boxes) |
| Classes | 11 (see below) |
| Document types | Financial, Scientific, Legal, Patents, Government, Manuals |
| Available on | [HuggingFace: ds4sd/DocLayNet](https://huggingface.co/datasets/ds4sd/DocLayNet) |
| License | CC BY 4.0 |

### The 11 Classes

| Class | What it is | Your need |
|---|---|---|
| **Title** | Document/section title | ✅ PRIMARY — defines chunk boundaries |
| **Section-header** | Subsection headings | ✅ PRIMARY — defines chunk boundaries |
| **Text** | Body paragraphs | ✅ Content within chunks |
| **Table** | Data tables | ✅ Content within chunks |
| **Picture** | Images/figures | ✅ Content within chunks |
| **Caption** | Figure/table captions | ✅ Content within chunks |
| **List-item** | Bullet/numbered list items | ✅ Content within chunks |
| Page-header | Running header | ❌ Ignore |
| Page-footer | Running footer/page numbers | ❌ Ignore |
| Footnote | Footnote text | Low priority |
| Formula | Math equations | Low priority |

> **Tip:** You can filter DocLayNet to only train on the 6-7 classes you care about. Fewer classes = easier training, faster convergence.

### DocLayNet Size Variants

| Split | Pages |
|---|---|
| Train | 69,375 |
| Val | 6,489 |
| Test | 4,999 |

> **T4 Colab Tip:** DocLayNet-core is the full dataset (~28GB images + annotations). For initial experiments, use a 10-20% stratified subset (~7,000 training pages) — still large enough to train a solid model.

---

## 4. Model Architecture Options — Compared

Here are all the serious options, analyzed for your specific constraints:

### Option A — YOLOv8 (Recommended ✅)

**What it is:** Real-time object detection with CSPDarknet backbone + FPN neck + detection head.

| Property | Detail |
|---|---|
| Framework | Ultralytics (PyTorch) |
| Variants | n (3.2M params) · s (11.2M) · m (25.9M) · l · x |
| Input | Any resolution, default 640×640 |
| Output | Bounding boxes + class probabilities |
| DocLayNet format | Native COCO → converts to YOLO format easily |
| T4 feasibility | ✅ yolov8n/s fits comfortably, yolov8m is possible |
| Training speed (T4) | ~2-4 min/epoch on subset |
| mAP on DocLayNet | ~70-75 mAP with yolov8m |

**Why it's best for you:**
- DocLayNet COCO format → YOLO format conversion is a 20-line script
- Trains end-to-end in pure PyTorch
- Active community, excellent docs
- You can **build the backbone from scratch** (conv blocks) while keeping the training loop from Ultralytics — or build entirely custom in PyTorch

---

### Option B — Faster R-CNN

**What it is:** Two-stage detector: Region Proposal Network → ROI head.

| Property | Detail |
|---|---|
| Backbone | ResNet-50 / ResNet-101 + FPN |
| T4 feasibility | ⚠️ Tight — batch size 4-8, imgsz 640 |
| Training speed | ~5-10 min/epoch, slower than YOLO |
| mAP on DocLayNet | ~72-76 mAP (IBM original baseline) |
| Complexity | High — two-stage architecture, harder to implement from scratch |

**Verdict:** Slightly higher accuracy than YOLOv8s but much slower and harder to implement from scratch. Not worth it on T4.

---

### Option C — RT-DETR (State of the Art in 2024)

**What it is:** Real-Time DEtection TRansformer — combines ViT encoder + efficient detection head.

| Property | Detail |
|---|---|
| Params | ~32M (RT-DETR-L) |
| T4 feasibility | ⚠️ Very tight — may OOM at batch > 4 |
| mAP on DocLayNet | ~78-80 mAP (best among real-time models) |
| Complexity | High — transformer attention is hard to implement from scratch |
| Training speed | Slow on T4 |

**Verdict:** Best accuracy, but too heavy for free T4. Save for when you have an A100.

---

### Option D — Custom Lightweight CNN Detector (True "from scratch")

If you want to genuinely implement the **architecture yourself** in raw PyTorch, this is the approach:

**Architecture:**
```
Input: PDF page image (640×640×3)
    │
    ▼
[Backbone — Custom Feature Extractor]
    Conv 3×3, 32, stride 2       → 320×320
    Conv 3×3, 64, stride 2       → 160×160
    3× ResBlock(64)
    Conv 3×3, 128, stride 2      → 80×80
    3× ResBlock(128)
    Conv 3×3, 256, stride 2      → 40×40
    3× ResBlock(256)
    Conv 3×3, 512, stride 2      → 20×20
    2× ResBlock(512)
    │
    ▼
[Neck — Feature Pyramid Network (FPN)]
    Upsample + concat:
    P5 (20×20) → P4 (40×40) → P3 (80×80)
    (captures both small titles and large text blocks)
    │
    ▼
[Detection Head — per scale]
    For each of P3, P4, P5:
        Conv 1×1 → num_anchors × (5 + num_classes)
        5 = [x, y, w, h, objectness]
        num_classes = 7 (your filtered set)
    │
    ▼
[Post-processing]
    Non-Maximum Suppression (NMS)
    → Final boxes + class labels
```

**Parameters:** ~8-12M depending on depth choices — fits on T4 easily.

**Loss function:**
```
Total Loss = λ_box × CIoU_loss + λ_obj × BCE_loss + λ_cls × CE_loss
```

**Verdict:** Best for learning. You understand every weight. ~70 mAP achievable with good training. Takes more code (~500-800 lines of pure PyTorch) but this is exactly what "from scratch" means.

---

## 5. My Recommendation — What to Build and Why

> **Recommended: Custom Lightweight YOLO-style Detector in raw PyTorch**

Here's why:

| Criterion | Reason |
|---|---|
| **"From scratch" spirit** | You write the backbone, FPN, detection head, loss function yourself — no black boxes |
| **T4 feasible** | ~10M params, batch 16 at imgsz 640 fits in 10GB VRAM |
| **DocLayNet fit** | Object detection is the natural task — bounding box annotations used directly |
| **Achievable mAP** | 65-72 mAP is realistic on T4 with 50-100 epochs on a DocLayNet subset |
| **Integrates cleanly** | Output (boxes + classes) maps directly to your chunking post-processing logic |
| **Learning value** | You understand CIoU loss, FPN, NMS, anchor boxes — all core DL skills |

### Architecture Decision Summary

```
Backbone:   Custom ResNet-style CNN (5 stages, ~6M params)
Neck:       FPN (3 scales: 80×80, 40×40, 20×20)
Head:       YOLO-style per-scale detection head
Loss:       CIoU + BCE objectness + CrossEntropy class
Input:      640×640 RGB (PDF page rendered at 72-150 DPI)
Output:     Bounding boxes + {Title, Section-header, Text, Table, Picture, List-item, Caption}
```

---

## 6. T4 GPU Budget — Will It Fit?

The free Colab T4 has **~16GB VRAM** (usable ~12-14GB after system overhead).

| Config | VRAM Usage | Feasible? |
|---|---|---|
| Custom model (10M params), batch=16, imgsz=640 | ~6-8 GB | ✅ Comfortable |
| Custom model (10M params), batch=32, imgsz=640 | ~10-12 GB | ✅ Possible |
| YOLOv8s, batch=16, imgsz=640 | ~7 GB | ✅ Comfortable |
| YOLOv8m, batch=8, imgsz=640 | ~10 GB | ✅ Possible |
| YOLOv8m, batch=16, imgsz=1024 | ~15 GB | ⚠️ Risky |
| RT-DETR-L, batch=8, imgsz=640 | ~13-15 GB | ⚠️ Very tight |

**Colab session time:** Free T4 gives ~3-4 hours per session. With a 10K-image subset:
- ~2 min/epoch → 100 epochs ≈ 3.3 hours ✅ fits in one session
- Save checkpoint every 10 epochs to Google Drive

---

## 7. Training Strategy (Colab T4)

```python
# Recommended training config for T4 free tier

DATA_SUBSET     = 10_000   # pages from DocLayNet train split
IMG_SIZE        = 640
BATCH_SIZE      = 16       # use gradient accumulation if OOM
EPOCHS          = 100
LR              = 1e-3     # cosine decay to 1e-5
WARMUP_EPOCHS   = 3
CLASSES         = ['Title', 'Section-header', 'Text', 
                   'Table', 'Picture', 'List-item', 'Caption']
```

### Tricks to Maximize T4 Efficiency

| Trick | What it does |
|---|---|
| **Mixed precision (fp16)** | Halves VRAM usage, speeds up training ~1.5-2x |
| **Gradient accumulation (steps=4)** | Simulate batch=64 while only holding batch=16 in memory |
| **torch.compile()** | PyTorch 2.0+ — ~10-20% speed boost for free |
| **Mosaic augmentation** | Stitch 4 images → 4x data diversity per batch, no extra memory |
| **DocLayNet subset** | Start with 10-20% of train set — still ~7K pages, sufficient for first run |
| **Save to Google Drive** | Checkpoint every 10 epochs so Colab disconnect doesn't kill progress |

### Data Augmentation (important for documents!)

```python
# Document-specific augmentations
- Random crop (with box correction)
- Random horizontal flip (DISABLED — text directionality matters)
- Color jitter (±brightness, ±contrast) — PDFs have varying scan quality
- Random rotation ±5° — scanned PDFs may be slightly tilted
- Mosaic (combine 4 pages into 1) — YOLO standard, works great
- Scale jitter (0.5-1.5×)
```

> ❌ Do NOT use vertical flip or large rotations — document pages have fixed orientation.

---

## 8. Post-Processing Pipeline (Boxes → Chunks)

After your model outputs bounding boxes per page, this is how you produce title-based chunks:

```python

```

---

## 9. How This Replaces Unstructured in MVL-AgneticAI

```
Current flow (Unstructured.io):
    PDF → UnstructuredService.parse_pdf() → ParsedDocument
    
New flow (your DL model):
    PDF → YourDLModel.parse_pdf() → ParsedDocument  (same output shape!)
```

Your `UnstructuredService` returns a `ParsedDocument` with `ParsedPage` objects containing `text_blocks`, `images`, `tables`. You just need to implement the same interface:

```python
class YourDLModelService:
    def parse_pdf(self, pdf_path: str) -> ParsedDocument:
        # render each page → run model → build ParsedPage objects
        # return ParsedDocument with same structure as before
        ...
```

**The rest of the pipeline (PageIndex, MultimodalIndexer, RetrievalService) doesn't change at all.**

---

## 10. Phased Implementation Plan

### Phase 1 — Dataset & Baseline (Week 1)
- [ ] Download DocLayNet from HuggingFace
- [ ] Convert COCO format → YOLO format (script ~50 lines)
- [ ] Filter to your 7 classes
- [ ] Create 10K-page subset for fast iteration
- [ ] Train YOLOv8s as baseline (check your DocLayNet understanding)
- [ ] Evaluate: mAP@50, mAP@50-95, per-class AP

### Phase 2 — Custom Architecture (Week 2-3)
- [ ] Implement ResNet-style backbone in PyTorch from scratch
- [ ] Add FPN neck (3 scales)
- [ ] Implement YOLO-style detection head
- [ ] Implement CIoU + objectness + class loss
- [ ] Train on same 10K subset
- [ ] Compare mAP to YOLOv8s baseline

### Phase 3 — Full Dataset & Tuning (Week 3-4)
- [ ] Scale to full DocLayNet (~70K pages)
- [ ] Mixed precision (fp16)
- [ ] Cosine LR decay, warmup
- [ ] Mosaic + advanced augmentation
- [ ] Evaluate on DocLayNet test split

### Phase 4 — Integration (Week 4-5)
- [ ] Implement `YourDLModelService` class matching `ParsedDocument` interface
- [ ] Replace `UnstructuredService` in `multimodal_indexer.py`
- [ ] End-to-end test: upload PDF → index → chat

---

## 11. Metrics to Track

| Metric | Target | Notes |
|---|---|---|
| mAP@50 | > 75% | Primary — most commonly reported |
| mAP@50-95 | > 55% | Stricter IoU threshold |
| Title AP | > 80% | Most critical for your chunking task |
| Section-header AP | > 75% | Also critical |
| Inference speed | < 100ms/page | Fast enough for production |
| Training VRAM | < 12GB | T4 safe zone |

---

## Summary — Quick Reference

| Decision | Choice | Why |
|---|---|---|
| **Task** | Object Detection (bounding boxes + class) | Natural fit for DLA |
| **Dataset** | DocLayNet (7 of 11 classes) | Best DLA dataset, COCO format, free |
| **Architecture** | Custom ResNet backbone + FPN + YOLO head | True "from scratch", T4 feasible, learnable |
| **Loss** | CIoU + BCE + CrossEntropy | Standard object detection loss trio |
| **Input size** | 640×640 | Fits T4, good for document resolution |
| **Batch size** | 16 (fp16) | Safe for T4 16GB |
| **Baseline to beat** | YOLOv8s mAP on DocLayNet | Gives you a reference ceiling |
| **Post-processing** | Title/Section-header boxes → chunk boundaries | Replaces Unstructured element grouping |
| **Text extraction** | PyMuPDF (fitz) for text regions | Free, accurate, no OCR needed for digital PDFs |
