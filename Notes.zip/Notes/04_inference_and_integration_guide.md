# Guide 4 — Inference, Post-Processing & MVL-AgneticAI Integration

> **Goal:** Load your trained checkpoint, run it on real PDFs, convert bounding boxes into title-based document chunks, and drop in as a replacement for `UnstructuredService`.

---

## Step 1 — Load Trained Model

```python
import torch
from model import DocumentLayoutModel

def load_model(checkpoint_path: str, device: str = 'cuda') -> DocumentLayoutModel:
    model = DocumentLayoutModel(num_classes=7, num_anchors=3)
    ckpt  = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(ckpt['model_state'])
    model.eval()
    model.to(device)
    print(f"✅ Loaded checkpoint from epoch {ckpt['epoch']} | Loss: {ckpt['loss']:.4f}")
    return model

device = 'cuda' if torch.cuda.is_available() else 'cpu'
model  = load_model('/content/drive/MyDrive/DL_checkpoints/epoch_100.pt', device)
```

---

## Step 2 — PDF Page → Tensor

```python
import fitz  # PyMuPDF
import numpy as np
from PIL import Image
import torch
import torchvision.transforms.functional as TF

DPI = 150   # 150 DPI → ~1240×1754px → resize to 640 for model
IMG_SIZE = 640
MEAN = [0.485, 0.456, 0.406]
STD  = [0.229, 0.224, 0.225]

def pdf_page_to_tensor(page: fitz.Page) -> tuple[torch.Tensor, float, float]:
    """
    Render a PDF page at DPI, resize to IMG_SIZE×IMG_SIZE,
    return (tensor, scale_x, scale_y) for coordinate recovery.
    """
    mat = fitz.Matrix(DPI/72, DPI/72)
    pix = page.get_pixmap(matrix=mat, colorspace=fitz.csRGB)
    img = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)

    orig_w, orig_h = img.size
    img_resized = img.resize((IMG_SIZE, IMG_SIZE), Image.BILINEAR)

    scale_x = orig_w / IMG_SIZE
    scale_y = orig_h / IMG_SIZE

    tensor = TF.to_tensor(img_resized)  # [3, 640, 640], values [0,1]
    tensor = TF.normalize(tensor, MEAN, STD)
    return tensor.unsqueeze(0), scale_x, scale_y  # [1,3,640,640]
```

---

## Step 3 — Decode Model Output + NMS

```python
import torchvision.ops as ops

CLASS_NAMES = ['Caption','List-item','Picture','Section-header','Table','Text','Title']

# Anchors (normalized) — must match what you used during training
ANCHORS = [
    [(0.04,0.02),(0.07,0.04),(0.10,0.06)],   # small  (P3)
    [(0.15,0.05),(0.25,0.08),(0.40,0.10)],   # medium (P4)
    [(0.50,0.07),(0.70,0.15),(0.90,0.30)],   # large  (P5)
]

def decode_predictions(
    preds: tuple,
    anchors: list,
    img_size: int = 640,
    conf_thresh: float = 0.25,
    iou_thresh: float = 0.45,
    device: str = 'cuda'
) -> list[dict]:
    """
    Decode raw model output into a list of detections.
    Each detection: {'box': [x1,y1,x2,y2], 'class': int, 'class_name': str, 'conf': float}
    """
    all_boxes  = []
    all_scores = []
    all_classes = []

    for scale_idx, pred in enumerate(preds):  # pred: (1, 36, H, W)
        B, C, H, W = pred.shape
        num_anchors = len(anchors[scale_idx])
        num_classes = C // num_anchors - 5

        # Reshape: (1, num_anchors, 5+num_classes, H, W)
        pred = pred.view(B, num_anchors, 5+num_classes, H, W)
        pred = pred.permute(0, 1, 3, 4, 2).contiguous()  # (1, A, H, W, 5+C)

        # Build grid
        grid_y, grid_x = torch.meshgrid(
            torch.arange(H, device=device),
            torch.arange(W, device=device),
            indexing='ij'
        )

        for a_idx, (aw, ah) in enumerate(anchors[scale_idx]):
            p = pred[0, a_idx]  # (H, W, 5+C)

            tx = (torch.sigmoid(p[..., 0]) + grid_x) / W   # x_center norm
            ty = (torch.sigmoid(p[..., 1]) + grid_y) / H   # y_center norm
            tw = torch.sigmoid(p[..., 2]) * aw * 2          # width norm
            th = torch.sigmoid(p[..., 3]) * ah * 2          # height norm
            obj = torch.sigmoid(p[..., 4])                  # objectness
            cls = torch.sigmoid(p[..., 5:])                 # class probs

            conf = obj.unsqueeze(-1) * cls  # (H, W, num_classes)
            max_conf, max_cls = conf.max(dim=-1)

            mask = max_conf > conf_thresh
            if not mask.any():
                continue

            # Convert center format → corner format
            x1 = (tx - tw/2)[mask] * img_size
            y1 = (ty - th/2)[mask] * img_size
            x2 = (tx + tw/2)[mask] * img_size
            y2 = (ty + th/2)[mask] * img_size

            boxes = torch.stack([x1,y1,x2,y2], dim=-1)
            all_boxes.append(boxes)
            all_scores.append(max_conf[mask])
            all_classes.append(max_cls[mask])

    if not all_boxes:
        return []

    all_boxes   = torch.cat(all_boxes)
    all_scores  = torch.cat(all_scores)
    all_classes = torch.cat(all_classes)

    # NMS per class
    keep = ops.batched_nms(all_boxes.float(), all_scores.float(), all_classes, iou_thresh)

    results = []
    for i in keep:
        cls_id = all_classes[i].item()
        results.append({
            'box': all_boxes[i].tolist(),          # [x1,y1,x2,y2] in 640-space
            'class': cls_id,
            'class_name': CLASS_NAMES[cls_id],
            'conf': all_scores[i].item()
        })
    return results
```

---

## Step 4 — Run Inference on a Full PDF

```python
@torch.no_grad()
def run_inference_on_pdf(
    pdf_path: str,
    model: DocumentLayoutModel,
    device: str = 'cuda'
) -> list[list[dict]]:
    """
    Returns a list (one per page) of detection dicts with ORIGINAL page coordinates.
    """
    doc = fitz.open(pdf_path)
    all_page_detections = []

    for page_num, page in enumerate(doc):
        tensor, scale_x, scale_y = pdf_page_to_tensor(page)
        tensor = tensor.to(device)

        with torch.autocast(device_type='cuda', dtype=torch.float16):
            preds = model(tensor)

        detections = decode_predictions(preds, ANCHORS, img_size=640, device=device)

        # Scale boxes back to original page coordinates
        for det in detections:
            x1,y1,x2,y2 = det['box']
            det['box_orig'] = [x1*scale_x, y1*scale_y, x2*scale_x, y2*scale_y]
            det['page'] = page_num

        all_page_detections.append(detections)
        print(f"Page {page_num+1}/{len(doc)}: {len(detections)} detections")

    doc.close()
    return all_page_detections
```

---

## Step 5 — Post-Processing: Boxes → Document Chunks

```python
from dataclasses import dataclass, field

@dataclass
class DocumentChunk:
    section_title: str
    start_page: int
    end_page: int
    content_blocks: list = field(default_factory=list)  # text/table/picture blocks


def detections_to_chunks(
    all_page_detections: list[list[dict]],
    pdf_path: str
) -> list[DocumentChunk]:
    """
    Convert per-page detections into title-based document chunks.
    1. Collect all Title/Section-header detections across all pages.
    2. Sort by (page, y_top) → reading order.
    3. Each title opens a new chunk; content blocks fill the current chunk.
    """
    doc = fitz.open(pdf_path)

    # Collect heading anchors: (page, y_top, detection)
    headings = []
    for page_num, detections in enumerate(all_page_detections):
        for det in detections:
            if det['class_name'] in ('Title', 'Section-header'):
                y_top = det['box_orig'][1]
                headings.append((page_num, y_top, det))

    # Sort by reading order
    headings.sort(key=lambda x: (x[0], x[1]))

    if not headings:
        # No headings found — return entire PDF as one chunk
        full_text = ''.join(page.get_text() for page in doc)
        return [DocumentChunk(
            section_title='(Document)',
            start_page=0,
            end_page=len(doc)-1,
            content_blocks=[{'type': 'text', 'text': full_text}]
        )]

    # Build chunks
    chunks = []
    for i, (pg, y, heading_det) in enumerate(headings):
        # Title text: extract via PyMuPDF using the bounding box
        x1,y1,x2,y2 = heading_det['box_orig']
        page = doc[pg]
        rect  = fitz.Rect(x1, y1, x2, y2)
        title_text = page.get_text('text', clip=rect).strip()

        # Content: everything from this heading to the next
        next_pg, next_y = headings[i+1][:2] if i+1 < len(headings) else (len(doc)-1, 9999)
        content_blocks = []

        for p in range(pg, next_pg + 1):
            page_dets = all_page_detections[p]
            for det in page_dets:
                if det['class_name'] in ('Title', 'Section-header'):
                    continue
                det_y = det['box_orig'][1]
                # Include if after current heading and before next heading
                if p == pg and det_y < y:
                    continue
                if p == next_pg and det_y >= next_y:
                    continue
                content_blocks.append(det)

        chunks.append(DocumentChunk(
            section_title=title_text or f"Section {i+1}",
            start_page=pg,
            end_page=next_pg,
            content_blocks=content_blocks
        ))

    doc.close()
    return chunks
```

---

## Step 6 — Drop-In Replacement for UnstructuredService

```python
class YourDLModelService:
    """
    Drop-in replacement for UnstructuredService.
    Produces the same ParsedDocument output shape.
    """
    def __init__(self, checkpoint_path: str, device: str = 'cuda'):
        self.model  = load_model(checkpoint_path, device)
        self.device = device

    def parse_pdf(self, pdf_path: str) -> 'ParsedDocument':
        # 1. Run detection on every page
        all_detections = run_inference_on_pdf(pdf_path, self.model, self.device)

        # 2. Convert detections → chunks
        chunks = detections_to_chunks(all_detections, pdf_path)

        # 3. Extract text content using PyMuPDF for each text-type box
        doc = fitz.open(pdf_path)
        parsed_pages = []
        for page_num, detections in enumerate(all_detections):
            text_blocks = []
            images      = []
            tables      = []

            page = doc[page_num]
            for det in detections:
                x1,y1,x2,y2 = det['box_orig']
                rect = fitz.Rect(x1,y1,x2,y2)
                cls  = det['class_name']

                if cls in ('Text', 'Caption', 'List-item', 'Section-header', 'Title'):
                    text = page.get_text('text', clip=rect).strip()
                    if text:
                        text_blocks.append({'type': cls, 'text': text, 'bbox': det['box_orig']})

                elif cls == 'Picture':
                    try:
                        clip = page.get_pixmap(clip=rect)
                        import base64, io
                        buf = io.BytesIO(clip.tobytes('png'))
                        b64 = base64.b64encode(buf.getvalue()).decode()
                        images.append({'type': 'image', 'data': b64, 'bbox': det['box_orig']})
                    except Exception:
                        pass

                elif cls == 'Table':
                    # For now: extract as text; replace with table parser later
                    text = page.get_text('text', clip=rect).strip()
                    tables.append({'type': 'table', 'text': text, 'bbox': det['box_orig']})

            parsed_pages.append(ParsedPage(
                page_number=page_num,
                text_blocks=text_blocks,
                images=images,
                tables=tables
            ))

        doc.close()
        return ParsedDocument(pages=parsed_pages, chunks=chunks)

# Usage — identical to how you'd call UnstructuredService:
service = YourDLModelService(
    checkpoint_path='/content/drive/MyDrive/DL_checkpoints/epoch_100.pt'
)
parsed = service.parse_pdf('/path/to/document.pdf')

print(f"{len(parsed.pages)} pages parsed")
print(f"{len(parsed.chunks)} sections found")
for chunk in parsed.chunks[:5]:
    print(f"  '{chunk.section_title}' — pages {chunk.start_page}–{chunk.end_page}")
```

---

## Step 7 — Evaluate Your Model

```python
# Quick mAP check using Ultralytics val (if you also kept the YOLOv8 baseline)
# For your custom model, use torchmetrics:

!pip install torchmetrics -q

from torchmetrics.detection.mean_ap import MeanAveragePrecision

metric = MeanAveragePrecision(iou_type='bbox', class_metrics=True)

model.eval()
with torch.no_grad():
    for images, targets in val_loader:
        preds = model(images.to(device))
        decoded = decode_predictions(preds, ANCHORS, device=device)

        # Format for torchmetrics
        preds_fmt   = [{'boxes': ..., 'scores': ..., 'labels': ...}]
        targets_fmt = [{'boxes': ..., 'labels': ...}]
        metric.update(preds_fmt, targets_fmt)

results = metric.compute()
print(f"mAP@50:    {results['map_50']:.3f}")
print(f"mAP@50-95: {results['map']:.3f}")
for i, name in enumerate(CLASS_NAMES):
    print(f"  AP {name:20s}: {results['map_per_class'][i]:.3f}")
```

---

## Target Metrics Summary

| Metric | Target | Critical? |
|---|---|---|
| mAP@50 | > 75% | Primary |
| mAP@50-95 | > 55% | Secondary |
| Title AP | > 80% | ✅ YES — drives chunking |
| Section-header AP | > 75% | ✅ YES — drives chunking |
| Inference speed | < 100ms/page | Production |

---

## Integration Checklist

- [ ] Checkpoint saved and accessible from production environment
- [ ] `YourDLModelService` implements same interface as `UnstructuredService`
- [ ] `ParsedDocument` / `ParsedPage` shape matches what `MultimodalIndexer` expects
- [ ] Swap import in `multimodal_indexer.py`: `UnstructuredService` → `YourDLModelService`
- [ ] End-to-end test: upload PDF → index → query chat → correct section retrieved
- [ ] Measure inference latency on realistic PDFs (10, 50, 100 pages)

---

## Phase Roadmap Reminder

```
Phase 1 (Week 1):  Dataset setup + YOLOv8s baseline  ← 02_dataset_guide.md
Phase 2 (Week 2):  Custom arch from scratch          ← 03_training_guide.md (this)
Phase 3 (Week 3):  Full DocLayNet + tuning           ← scale up training
Phase 4 (Week 4):  Integration + end-to-end test     ← this file
```

You're replacing Unstructured.io — the rest of the MVL-AgneticAI pipeline (PageIndex, MultimodalIndexer, RetrievalService) stays untouched.
